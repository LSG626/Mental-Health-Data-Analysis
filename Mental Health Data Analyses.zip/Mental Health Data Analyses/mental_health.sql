-- 1. Risk Category Distribution
CREATE TABLE risk_category_distribution AS
SELECT 
    Risk_Category, 
    COUNT(*) AS total_people
FROM cleaned_mental_health
GROUP BY Risk_Category;

-- 2. Risk Score vs Treatment
CREATE TABLE risk_vs_treatment AS
SELECT 
    treatment, 
    CAST(AVG(Risk_Score) AS DECIMAL(5,2)) AS avg_risk_score, 
    COUNT(*) AS total_people
FROM cleaned_mental_health
GROUP BY treatment;

-- 3. Country-Level Analysis
CREATE TABLE country_risk_analysis AS
SELECT 
    Country, 
    CAST(AVG(Risk_Score) AS DECIMAL(5,2)) AS avg_risk, 
    COUNT(*) AS total_people
FROM cleaned_mental_health
GROUP BY Country;

-- 4. Occupation Risk Analysis
CREATE TABLE occupation_risk_analysis AS
SELECT 
    Occupation, 
    CAST(AVG(Risk_Score) AS DECIMAL(5,2)) AS avg_risk, 
    COUNT(*) AS total_people
FROM cleaned_mental_health
GROUP BY Occupation;

-- 5. Behavioral High Risk
CREATE TABLE behavioral_high_risk AS
SELECT 
    Growing_Stress, 
    Coping_Struggles, 
    Mood_Swings, 
    COUNT(*) AS total_people
FROM cleaned_mental_health
WHERE Risk_Category = 'High Risk'
GROUP BY Growing_Stress, Coping_Struggles, Mood_Swings;

-- 6. Demographic Breakdown
CREATE TABLE demographic_risk AS
SELECT 
    Gender, 
    Risk_Category, 
    COUNT(*) AS total
FROM cleaned_mental_health
GROUP BY Gender, Risk_Category;

